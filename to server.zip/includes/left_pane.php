<div class="span2 left_pane">
    <br />
    <a href="index.php"><img src="img/ih_logo.gif" alt="Islamic Help Tanzania" width='200'/></a>
    <br />

    <br />
    <a class='red_block2' href='http://www.islamichelp.org.uk'><img src="img/english_flag.png" alt="englishflag"> Visit Islamic Help UK</a>
    <br />

    <div class='left_red_block'>
        <div class='red_grass'>&nbsp;</div>
        <br />
        <div class='red_block'>iHelp Make A Difference</div>
    </div>
    <a href='donate.php?page=donate'>Donating</a>
    <br />
    <a href='volunteer.php?page=volunteer'>Volunteer</a>
    <br />
    <a href='vacancies.php?page=vacancies'>Vacancies</a>
    <br />
    <a href='mission.php?page=mission'>Mission Possible</a>
    <br />
    <a href='smallhands.php?page=smallhands'>Small Hands</a>
    
    
    <div class='left_red_block'>
        <div class='red_grass'>&nbsp;</div>
        <br />
        <div class='red_block'>iHelp Feed Tanzania</div>
    </div>
    <a href='qurbani.php?page=qurbani'>Qurbani</a>
    <br />
    <a href='food.php?page=food'>Food Security</a>
    <br />
    <a href='water.php?page=water'>Tone La Huruma</a>
    
    <div class='left_red_block'>
        <div class='red_grass'>&nbsp;</div>
        <br />
        <div class='red_block'>iHelp The Environment</div>
    </div>
    <a href='tfc.php?page=tfc'>Trees For Change</a>
    <br />
    <a href='eco_mosque.php?page=eco_mosque'>Eco Mosque</a>

    <div class='left_red_block'>
        <div class='red_grass'>&nbsp;</div>
        <br />
        <div class='red_block'>iHelp Sponsor an Orphan</div>
        </div>
        <a href='orphans.php?page=orphans'>Orphan Care</a>
        <br />
        <a href='eco_village.php?page=eco_village'>Children's Village</a>
    
    <div class='left_red_block'>
        <div class='red_grass'>&nbsp;</div>
        <br />
        <div class='red_block'>iHelp Empower People</div>
    </div>
    <a href='economic.php?page=economic'>Wezesha Maisha</a>
    <br />
    <a href='economic.php#tab2'>SACCOS</a>
    <br />
    <a href="economic.php#tab3">TREND</a>
    <br />
    <a href='cordoba.php?page=cordoba'>Cordoba School</a>
    <br />
    <a href='education.php?page=education'>Education & Training</a>
    
    <div class='left_red_block'>
        <div class='red_grass'>&nbsp;</div>
        <br />
        <div class='red_block'>iHelp Respond to Disasters</div>
    </div>
    <a href='jangwani.php?page=jangwani'>Jangwani Floods 2011</a>
    <br />
    <a href='somali.php?page=somali'>Somalia Droughts 2011</a>
    
    <br />
    <br />
    <a href="http://islamichelp.org.uk/images/IH_ProjectReport2013-WEB.pdf"><img src='images/ih_report2013.jpg' /></a>

    <br />
    <br />

    <iframe src="//www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2Fihelptz&amp;width&amp;layout=button_count&amp;action=like&amp;show_faces=false&amp;share=true&amp;height=21&amp;appId=182053658650792" scrolling="no" frameborder="0" style="border:none; overflow:hidden; height:21px;" allowTransparency="true"></iframe>

    <br />
    <br />

</div><!-- span2 (Left Pane) -->