</div><!-- row -->

</div><!-- container -->
<br />
<br />
<br />
<br />
<div id='footer'>
    <div class='black_grass_footer'></div>
    <div class='container'>
        <div class='row'>
            <div class='span2'><img src='img/ih_black_logo.jpg' alt='Islamic Help' /></div>
            <div class='span10'>
                <table class='span10'>
                    <tr>
                        <th>About Us</th>
                        <th>Donate</th>
                        <th>Make A Difference</th>
                        <th>Our Work</th>
                    </tr>
                    <tr>
                        <td><a href='about.php'>Islamic Help</a></td>
                        <td><a href='donate.php'>Donations Price Handles</a></td>
                        <td><a href='volunteer.php'>Volunteer</a></td>
                        <td><a href='water.php'>Water</a></td>

                    </tr>
                    <tr>
                        <td><a href='contact.php'>Contact Us</a></td>
                        <td><a href='donate.php'>Ways to Donate</a></td>
                        <td><a href='vacancies.php'>Vacancies</a></td>
                        <td><a href='eco_village.php'>Homes</a></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td><a href='events.php'>Events</a></td>
                        <td><a href='education.php'>Education & Training</a></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td><a href='economic.php'>Empowerment & Livelihood</a></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                </table>
                <p>Registered Charity Number 996793</p>
                <a href="vacancies.php">Vacancies</a>   |   
                <a href="terms.php">Terms & Conditions</a>   |   
                <a href="privacy.php">Privacy Policy</a>   |   
                <a href="contact.php">Contact Us</a>
            </div>
        </div>
    </div>
    <br />
    <br />
</div>
</body>
</html>