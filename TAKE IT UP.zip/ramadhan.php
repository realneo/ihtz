<?php include('includes/header.php'); ?>
<?php include('includes/left_pane.php'); ?>


<div class="span9">
    <div id='children'><img src='img/children.gif' alt='iHelp Tanzanians' /></div>
    <div id='giraffe' class='offset4'><img src='img/giraffe_tree.gif' alt='Tanzanian Giraffe' /></div>
    
    <?php include('includes/menu.php'); ?>
    <div class='row'>
        <div class='span9' id='infomation'>
            <h1>Ramadhan</h1>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>