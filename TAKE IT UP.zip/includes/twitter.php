
<div id="twitter-ticker">
   <!-- Twitter container, hidden by CSS and shown if JS is present -->

    <div id="top-bar">
        <!-- This contains the title and icon -->
        
        <!-- The twitter icon -->
        <div class='red_grass_tw'>&nbsp;</div>
        <h2 class="tut"><img src="images/twitter_64.png"  height='30' alt="Twitter icon" />@iHelp tz </h2>
        <!-- Title -->

    </div>

    <div id="tweet-container"><img id="loading" src="images/loading.gif" width="15" height="11" alt="Loading.." /></div>
    <!-- The loading gif animation - hidden once the tweets are loaded -->

    <div id="scroll"></div>
    <!-- Container for the tweets -->

</div>
