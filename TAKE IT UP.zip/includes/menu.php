<div class='row'>
    <div class='span7'>
        <nav>
            <ul>
                <li><a href="index.php?page=index">Home</a></li>
                <li><a href="about.php?page=about">About Us</a></li>
                <li><a href="#">Projects</a>
                    <ul>
                        <li><a href="water.php?page=water">Water Project</a>
                            <ul>
                                <li><a href="water.php?page=water">Tone La Huruma</a></li>
                            </ul>
                        </li>
                        
                        <li><a href="orphans.php?page=orphans">Orphan Care</a>
                            <ul>
                                <li><a href="orphans.php?page=orphans">Home Based</a></li>
                                <li><a href="eco_village.php?page=eco_village">Children's Village</a></li>
                            </ul>
                        </li>
                        <li><a href="education.php?page=education">Education</a>
                            <ul>
                                <li><a href="smallhands.php?page=smallhands">Small Hands</a></li>
                                <li><a href="cordoba.php?page=cordoba">Cordoba School</a></li>
                                <li><a href="education.php?page=education">Educational Seminars</a></li>
                            </ul>
                        </li>
                        <li><a href="environment.php?page=environment">Environmental Sustainability</a>
                            <ul>
                             <li><a href="tfc.php?page=tfc">Trees For Change</a></li>
                            </ul>
                        </li>
                        <li><a href="economic.php?page=economic">Economic Empowerment</a>
                            <ul>
                                <li><a href="economic.php?page=economic">Wezesha Maisha</a></li>
                                <li><a href="economic.php#tab2">SACCOS</a></li>
                                <li><a href="economic.php#tab3">TREND</a></li>
                            </ul>
                        </li>
                    </ul>
                 </li>
                 <li><a href="events.php?page=events">Events</a>
                     <ul>
                        <li><a href="events.php?page=events">Forthcoming Events</a></li>
                        <li><a href="events.php?page=events">Past Events</a></li>
                    </ul>
                 </li>
                 <li><a href="volunteer.php?page=volunteer">Get Involved</a>
                     <ul>
                         <li><a href="volunteer.php?page=volunteer">Volunteer</a></li>
                         <li><a href="vacancies.php?page=vacancies">Vacancies</a></li>
                     </ul>
                 </li>
                 <!--<li><a href="#">Latest</a></li>-->
                 <li><a href="contact.php?page=contact">Contact Us</a></li>
            </ul>
        </nav>
    </div>
    <div style="margin-top:140px"></div>
</div>
<div id='children'><img src='img/children.gif' alt='iHelp Tanzanians' /></div>
    <div id='giraffe' class='offset4'><img src='img/giraffe_tree.gif' alt='Tanzanian Giraffe' /></div>
    <div id='tanzania'><h3>TANZANIA</h3></div>
    <div id='number' class='offset6'><h2>+255 (0)222 772 227  </h2></div>
<div id="donate_btn">
            <div id="donate_bg"></div>
            <div id="donate_fg"><p><a href="donate.php?page=donate">DONATE NOW</a></p></div>
        </div>
    </div>