<?php session_start(); ?>
<!DOCTYPE html>
<html lang='en'>
    <head>
        <title>Islamic Help Tanzania</title>

        <link rel="icon"
              type="image/png"
              href="http://islamichelp.co.tz/favicon.png"/>

        <?php include('includes/meta_tags.php'); ?>


    <meta charset="UTF-8">

        <link href='css/bootstrap.css' rel='stylesheet' type='text/css' />
        <link href='css/flexslider/flexslider.css' rel='stylesheet' type='text/css' />
        <script src="js/jquery-1.10.2.min.js"></script>
        <script type='text/javascript' src='js/jquery.flexslider-min.js'></script>
        <script type='text/javascript' src='js/tweet_script.js'></script>
        
        <script src="js/bootstrap.js"></script>
        <script src="js/main.js"></script>







    </head>
    <body>
        <div id='tree'><img src='img/tree.gif' alt='Welcome to Islamic Help Tanzania'/></div><!-- tree -->
        
        <div class='black_grass'>&nbsp;</div><!-- black_grass -->
        <div id='red_strip'></div><!-- red_strip -->
        
        
        <div class='container'>
            